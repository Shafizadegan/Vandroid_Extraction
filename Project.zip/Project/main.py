# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
# import xmi
from bs4 import BeautifulSoup
import sqlite3
from pathlib import Path


def extraction(b_components, type_component, target):

    count_component = 0
    for ins in b_components:
        print(f"components {type_component}:", ins)
        count_component += 1

        instance_name = ins.get('Name')
        print("Name components:", instance_name)

        # check
        instance_permission = ins.get('Permission')
        print("PermissionName components:", instance_permission)

        instance_export = ins.get('Exported')
        if instance_export:
            instance_export = 1  # true
        if not instance_export:
            instance_export = 0  # false
        print("Exported instanceCA_export:", instance_export)

        # `Number of Filter`
        filters = ins.find_all('filters')
        number_filter = len(filters)
        if number_filter == 0:
            filter_check = 0
        else:
            filter_check = 1
        print("Check Filter:", filter_check)
        print("Number of Filter:", number_filter)

        connection.execute(f"INSERT OR IGNORE INTO {type_component}_{type_component} VALUES (?, ?, ?, ?, ?, ?)",
                           (count_component, target, instance_name, instance_export, instance_permission, filter_check))
        connection.commit()

        # `Number of Categories`
        count_filter = 0
        for instanceFilter in filters:
            count_filter += 1
            instance_filter_name = instanceFilter.get('Name')
            print("Name Filter:", instance_filter_name)

            comp_id = count_component
            print("comp_id Filter:", comp_id)

            categories = instanceFilter.find_all('categories')
            count_category = len(categories)
            if count_category == 0:
                categories_check = 0
            else:
                categories_check = 1
            print("Check Categories:", categories_check)
            print("Number of Category:", count_category)

            filter_id = count_filter

            connection.execute(f"INSERT OR IGNORE INTO {type_component}_filter VALUES (?, ?, ?, ?)",
                               (filter_id, instance_filter_name, categories_check, comp_id))
            connection.commit()

            count_category = 0
            for instanceCategory in categories:
                count_category += 1
                instance_category_name = instanceCategory.get('Name')
                print("Name Category:", instance_category_name)

                print("filter_id Category:", filter_id)

                connection.execute(f"INSERT OR IGNORE INTO {type_component}_category VALUES (?, ?, ?)",
                                   (count_category, instance_category_name, filter_id))
                connection.commit()

            actions = instanceFilter.find_all('actions')
            count_action = 0
            for instanceAction in actions:
                count_action += 1
                instance_action_name = instanceAction.get('Name')
                print("Name Action:", instance_action_name)

                print("filter_id Action:", filter_id)

                connection.execute(f"INSERT OR IGNORE INTO {type_component}_action VALUES (?, ?, ?)",
                                   (count_action, instance_action_name, filter_id))
                connection.commit()


# Press the green button in the gutter to run the script.
if __name__ == '__main__':

    # Connection Database
    connectionString = "B:/Term/Term7/Pro_Int/Vandroid_BackEnd-main/Vandroid_BackEnd-main/Vandroid/db.sqlite3"
    connection = sqlite3.connect(connectionString)

    with open('B:/Term/Term7/Pro_Int/AndroidApps/AndroidApps/app1/AndroidApplicationSecurityAspects.xml', 'r') as f:
        data = f.read()
    Bs_data = BeautifulSoup(data, "xml")

    # Define Target_Id
    target_id = 1

    # Finding all instances of tag
    # `information`
    nameApp = app_name = 'AndroidApplicationSecurityAspects'
    file_name = 'AndroidApplicationSecurityAspects.apk'
    state = Path("B:/Term/Term7/Pro_Int/AndroidApps/AndroidApps/app1/AndroidApplicationSecurityAspects.xml").stat()
    fileSize = state.st_size
    print("fileSize:", fileSize)

    b_information = Bs_data.find('www.ASAMM.com:ApplicationPolicyFile')
    appPackage = b_information.get("Package")
    appVersionCode = b_information.get("VersionCode")
    appVersionName = b_information.get("VersionName")
    print("appPackage:", appPackage)
    print("appVersionCode:", appVersionCode)
    print("appVersionName:", appVersionName)

    b_usesSDK = Bs_data.find('usesSDK')
    MinSdkVersion = b_usesSDK.get("MinSdkVersion")
    MaxSdkVersion = b_usesSDK.get("MaxSdkVersion")
    TargetSdkVersion = b_usesSDK.get("TargetSdkVersion")

    if not MinSdkVersion:
        MinSdkVersion = 1

    if not MaxSdkVersion:
        MaxSdkVersion = 1

    if not TargetSdkVersion:
        TargetSdkVersion = 1
    print("MinSdkVersion:", MinSdkVersion)
    print("MaxSdkVersion:", MaxSdkVersion)
    print("TargetSdkVersion:", TargetSdkVersion)

    b_app = Bs_data.find('app')
    appIcon = b_app.get("Icon")
    appLabel = b_app.get("Label")
    print("appIcon:", appIcon)
    print("appLabel:", appLabel)

    connection.execute("INSERT OR IGNORE INTO information_information VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                       (target_id, nameApp, file_name, app_name, appPackage, appLabel, appIcon, MinSdkVersion,
                        MaxSdkVersion, TargetSdkVersion, appVersionCode, appVersionName, fileSize))
    connection.commit()

    # `usesPermissions`
    count = 0
    b_usesPermissions = Bs_data.find_all('usesPermissions')
    for instance in b_usesPermissions:
        count += 1
        print("usesPermissions:", instance)
        instanceUP_name = instance.get('Name')
        print("Name usesPermissions:", instanceUP_name)

        instanceUP_status = instance.get('PermissionKind')
        if not instanceUP_status:
            instanceUP_status = "Normal"
        print("Status usesPermissions:", instanceUP_status)

        if instanceUP_name == "android.permission.ACCESS_FINE_LOCATION":
            info = "Allows an app to access precise location."
            description = "Allows an app to access precise location."

        #  change
        info = "Allows an app to access precise location."
        description = "Allows an app to access precise location."

        connection.execute("INSERT OR IGNORE INTO usesPermission_usespermission VALUES (?, ?, ?, ?, ?, ?)",
                           (count, target_id, instanceUP_name, info, description, instanceUP_status))
        connection.commit()

    # `customPermissions`
    count = 0
    b_customPermissions = Bs_data.find_all('customPermissions')
    for instance in b_customPermissions:
        count += 1
        print("customPermissions:", instance)
        instanceCP_name = instance.get('Name')
        print("Name customPermissions:", instanceCP_name)

        instanceCP_status = instance.get('PermissionKind')
        if not instanceCP_status:
            instanceCP_status = "Normal"
        print("Status usesPermissions:", instanceCP_status)

        # change
        info = "Allows an app to access precise location."
        description = "Allows an app to access precise location."

        connection.execute("INSERT OR IGNORE INTO customPermission_custompermission VALUES (?, ?, ?, ?, ?, ?)",
                           (count, target_id, instanceCP_name, info, description, instanceCP_status))
        connection.commit()

    # `APIPermissions`
    b_APIPermissions = Bs_data.find_all('APIPermissions')
    for instance in b_APIPermissions:
        print("APIPermissions:", instance)

        # `APICallPermissions`
        count = 0
        b_APICallPermissions = instance.find_all('APICallPermissions')
        if b_APICallPermissions:
            for instance_APICall in b_APICallPermissions:
                count += 1
                print("APICallPermissions:", instance_APICall)
                instanceAPICallP_name = instance_APICall.get('Name')
                print("Name APICallPermissions:", instanceAPICallP_name)

                instanceAPICallP_status = instance_APICall.get('PermissionKind')
                if not instanceAPICallP_status:
                    instanceAPICallP_status = "Normal"
                print(instanceAPICallP_status)

                if instanceAPICallP_name == "android.permission.BLUETOOTH":
                    info = "Allows applications to connect to paired bluetooth devices."

                # change
                info = "Allows applications to connect to paired bluetooth devices."

                connection.execute("INSERT OR IGNORE INTO APIPermission_apipermission VALUES (?, ?, ?, ?, ?)",
                                   (count, target_id, instanceAPICallP_name, info, instanceAPICallP_status))
                connection.commit()

    # `componentsBroadcastReceiver`
    b_componentsBroadcastReceiver = Bs_data.find_all('components', {'xsi:type': 'www.ASAMM.com:BroadcastReceiver'})
    extraction(b_componentsBroadcastReceiver, 'broadcastReceiversComponents', target_id)

    # `componentsَAliasActivity`
    # check_check
    b_componentsActivity = Bs_data.find_all('components', {'xsi:type': 'www.ASAMM.com:activityAlias'})
    extraction(b_componentsActivity, 'activityAliasComponents', target_id)

    # `componentsService`
    b_componentsService = Bs_data.find_all('components', {'xsi:type': 'www.ASAMM.com:Service'})
    extraction(b_componentsService, 'servicesComponents', target_id)

    # `componentsBroadcastReceiver`
    b_componentsBroadcastReceiver = Bs_data.find_all('components', {'xsi:type': 'www.ASAMM.com:BroadcastReceiver'})
    extraction(b_componentsBroadcastReceiver, 'broadcastReceiversComponents', target_id)

    # `dynamicRegisteredComponents`
    b_dynamicRegisteredComponents = Bs_data.find_all(
        'dynamicRegisteredComponents', {'xsi:type': 'www.ASAMM.com:DynamicRegisteredBroadcastReceiver'})
    extraction(b_dynamicRegisteredComponents, 'dynamicRegisteredComponents', target_id)

    # `componentsContentProvider`
    count = 0
    b_componentsContentProvider = Bs_data.find_all('components', {'xsi:type': 'www.ASAMM.com:ContentProvider'})
    for instanceCCP in b_componentsContentProvider:
        count += 1
        print("componentsContentProvider:", instanceCCP)

        instanceCCP_name = instanceCCP.get('Name')
        print("Name componentsContentProvider:", instanceCCP_name)

        # check
        instanceCCP_Permission = instanceCCP.get('Permission')
        print("PermissionName componentsContentProvider:", instanceCCP_Permission)

        instanceCPP_export = instanceCCP.get('Exported')
        if instanceCPP_export:
            instanceCPP_export = 1  # true
        if not instanceCPP_export:
            instanceCPP_export = 0  # false
        print("Exported instanceCCP_export:", instanceCPP_export)

        instanceCCP_authority = instanceCCP.get('Authority')
        print("Authority componentsContentProvider:", instanceCCP_authority)

        connection.execute("INSERT OR IGNORE INTO contentProvidersComponents_contentproviderscomponents VALUES (?, ?, ?, ?, ?, ?)",
                           (count, target_id, instanceCCP_name, instanceCPP_export, instanceCCP_Permission,
                            instanceCCP_authority))
        connection.commit()

    # `Intents`
    count = 0
    b_intents = Bs_data.find_all('intents')
    for instanceI in b_intents:
        count += 1
        print("Intents:", instanceI)

        instanceI_Name = instanceI.get('Name')
        print("Name Intent:", instanceI_Name)

        instanceI_SendComponentName = instanceI.get('SendComponentName')
        print("SendComponentName Intent:", instanceI_SendComponentName)

        instanceI_TargetComponentName = instanceI.get('TargetComponentName')
        print("TargetComponentName Intent:", instanceI_TargetComponentName)

        instanceI_IntentKind = instanceI.get('IntentKind')
        print("IntentKind Intent:", instanceI_IntentKind)

        instanceI_Permission = instanceI.get('Permission')
        print("Permission Intent:", instanceI_Permission)

        connection.execute(
            "INSERT OR IGNORE INTO intentMessages_intentmessages VALUES (?, ?, ?, ?, ?, ?, ?)",
            (count, target_id, instanceI_Name, instanceI_IntentKind, instanceI_Permission,
             instanceI_SendComponentName, instanceI_TargetComponentName))
        connection.commit()


# See PyCharm help at https://www.jetbrains.com/help/pycharm/

# countComActivity = 0
    # for instanceCA in b_componentsActivity:
    #     print("componentsActivity:", instanceCA)
    #     countComActivity += 1
    #
    #     instanceCA_name = instanceCA.get('Name')
    #     print("Name componentsActivity:", instanceCA_name)
    #
    #     #  check
    #     instanceCA_Permission = instanceCA.get('PermissionName')
    #     print("PermissionName componentsActivity:", instanceCA_Permission)
    #
    #     instanceCA_export = instanceCA.get('Exported')
    #     if instanceCA_export:
    #         instanceCA_export = 1   # true
    #     if not instanceCA_export:
    #         instanceCA_export = 0   # false
    #     print("Exported instanceCA_export:", instanceCA_export)
    #
    #     # `Number of Filter`
    #     filterCheck = instanceCA.find_all('filters')
    #     countFilter = len(filterCheck)
    #     print("Number of Filter:", countFilter)
    #
    #     # `Number of Categories`
    #     countFilter = 0
    #     for instanceFilter in filterCheck:
    #         countFilter += 1
    #         instanceFilter_Name = instanceFilter.get('Name')
    #         print("Name Filter:", instanceFilter_Name)
    #
    #         comp_id = countComActivity
    #         print("comp_id Filter:", comp_id)
    #
    #         categoriesCheck = instanceFilter.find_all('categories')
    #         countCategory = len(categoriesCheck)
    #         print("Number of Category:", countCategory)
    #
    #         filter_id = countFilter
    #         for instanceCategory in categoriesCheck:
    #             instanceCategory_Name = instanceCategory.get('Name')
    #             print("Name Category:", instanceCategory_Name)
    #
    #             print("filter_id Category:", filter_id)
    #
    #         actionsCheck = instanceFilter.find_all('actions')
    #         print("Number of Actions:", actionsCheck)
    #         for instanceAction in actionsCheck:
    #             instanceAction_Name = instanceAction.get('Name')
    #             print("Name Action:", instanceAction_Name)
    #
    #             print("filter_id Category:", filter_id)
